import json
import time
from eospageObjects.advance_search import eos_advance_search
from eospageObjects.package_entry import package_entry
from utilities.readProperties import ReadEOSurlConfig
from Testcases.configtest import setup
from eospageObjects.facility_dashboard import eos_facility_dashboard
from eospageObjects.daily_closeout_dashboard import eos_daily_closeout_dashboard
from utilities.common_util import generate_random_string
from eospageObjects.bolt_menu import eos_bolt_menu
from eospageObjects.bolt_menu_All_EOS_Reports import eos_bolt_menu_all_eos_reports


# https://dev.azure.com/OnTracDevelopment/Holistic%20Software%20Destroyers/_workitems/edit/2489

class Test_TC_2489:
    EOSURL = ReadEOSurlConfig.getEOSuRL()
    testDataFile = open('.\\Data\\advance_search.json')
    data = json.load(testDataFile)
    testDataFile2 = open('.\\Data\\daily_closeout.json')
    daily_closeout_dashboard_data = json.load(testDataFile2)

    def test_TC_2489(self, setup):
        self.driver = setup
        self.advance_search = eos_advance_search(self.driver)
        self.packageEntry = package_entry(self.driver)
        self.bolt_menu_dashboard = eos_bolt_menu(self.driver)
        self.facility_dashboard = eos_facility_dashboard(self.driver)
        self.dailyClouseout = eos_daily_closeout_dashboard(self.driver)
        self.all_eos_reports_dashboard = eos_bolt_menu_all_eos_reports(self.driver)
        self.driver.get(self.EOSURL)
        self.driver.maximize_window()
        self.driver.implicitly_wait(20)
        self.advance_search.change_facility_in_profile(
            self.data["facility_one"])  # this function works consistently for changing facility.
        self.packageEntry.click_package_entry()
        time.sleep(2)
        stop_name_random = "tc-" + generate_random_string(8)
        barcode = self.packageEntry.create_a_package(customer_name=self.data["customer_name"],
                                                     forward_branch=self.data["forward_branch"],
                                                     stop_name=stop_name_random,
                                                     address_line1=self.data["address_line1"], city=self.data["city"],
                                                     state=self.data["state"], zip=self.data["zip"])
        time.sleep(20)
        self.driver.get(self.EOSURL)

        self.advance_search.change_facility_in_profile(self.data["facility_one"])
        self.advance_search.search_packg_in_advance_search(barcode)
        self.advance_search.assign_contractor_to_package()
        time.sleep(10)
        self.bolt_menu_dashboard.go_to_a_bolt_menu_view_report(self.data["mls_facility_route"])
        self.all_eos_reports_dashboard.verify_facility_route_report()
        self.driver.get(self.EOSURL)
        self.advance_search.change_facility_in_profile(self.data["facility_one"])
        self.advance_search.search_packg_in_advance_search(barcode)
        self.advance_search.click_barcode1()
        self.advance_search.change_package_status(self.data["package_status"],
                                                  self.data["package_exception"])
        time.sleep(10)
        self.all_eos_reports_dashboard.navigate_to_route_mls_report()
